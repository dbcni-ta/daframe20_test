package com.cni.fw.db.conf.vmsds.reader;

import java.io.File;
import java.io.FileInputStream;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import com.cni.fw.db.conf.vmsds.binder.DataSourceListType;
import com.cni.fw.db.conf.vmsds.binder.DataSourceType;
import com.cni.fw.db.conf.vmsds.binder.VmsDataSource;
import com.cni.fw.ff.exception.FrameException;
import com.cni.fw.ff.log.CommonLog;



/**
 * VMS데이타소스 설정파일(vms-ds.xsd) 리더 
 * <pre>
 * 2007. 08. 09
 * </pre>
 * @version : 1.0 
 * @author : WinterMute (Jeon Chan-Mo)
 */
public class VmsDataSourceConfigReader extends CommonLog {

	private File configFile = null;
	
	private VmsDataSource vmsDataSource = null;
	
	/**
	 * 생성자
	 * <pre>
	 * 2007. 08. 09
	 * </pre>
	 */
	public VmsDataSourceConfigReader() {
		super(VmsDataSourceConfigReader.class);
	}
	
	/**
	 * 초기화
	 * <pre>
	 * 2007. 08. 09
	 * </pre>
	 * @throws FrameException 
	 */
	public void initialize(String fileName) throws FrameException {
		if (fileName == null) {
			throw new FrameException("VMS-DataSource 구성 파일("+fileName+")을 찾을 수 없습니다. 설정을 확인하십시요.");
		}
		
		fileName = fileName.replace('\\', '/');
		configFile = new File(fileName);
	}
	
	/**
	 * 파일 로드 및 XML 언마샬링
	 * <pre>
	 * 2007. 08. 10
	 * </pre>
	 * @throws FrameException 
	 */
	public void load() throws FrameException {
        try {
        	JAXBContext jc = JAXBContext.newInstance("com.cni.fw.db.conf.vmsds.binder");
            Unmarshaller u = jc.createUnmarshaller();
            vmsDataSource = (VmsDataSource) u.unmarshal(new FileInputStream(configFile));
        } catch(Exception e) {
        	throw new FrameException(e);
        }
	}
	
	/**
	 * 프레임리스트 확인.
	 * 
	 * <pre>
	 * 2007. 08. 10
	 * </pre>
	 */
	public void show() {

		DataSourceListType dataSourceListType = vmsDataSource.getDataSourceList();
		DataSourceType dataSourceType = null;
		List dataSourceList = dataSourceListType.getDataSource();
		
		int cnt = 1;
		
		for (int i = 0; i < dataSourceList.size(); i++) {
			dataSourceType = (DataSourceType) dataSourceList.get(i);
			if (dataSourceType.isUsing()) {
				fatal("VMS-DS #"+cnt+"-"+dataSourceType.getName()+ " : "+dataSourceType.getJndiName() );
				cnt++;
			}
		}
		
	}

	public VmsDataSource getVmsDataSource() {
		return vmsDataSource;
	}


}
