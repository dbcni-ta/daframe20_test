package com.cni.fw.ff.conf.frame.reader;

import java.io.File;
import java.io.FileInputStream;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import com.cni.fw.ff.conf.frame.binder.FrameConfig;
import com.cni.fw.ff.conf.frame.binder.FrameListType;
import com.cni.fw.ff.conf.frame.binder.FrameType;
import com.cni.fw.ff.exception.FrameException;
import com.cni.fw.ff.log.CommonLog;



/**
 * 기반프레임워크 설정파일(Frame.xsd) 리더 
 * <pre>
 * 2007. 08. 09
 * </pre>
 * @version : 1.0 
 * @author : WinterMute (Jeon Chan-Mo)
 */
public class FrameConfigReader extends CommonLog {

	private File configFile = null;
	
	private FrameConfig frameConfig = null;
	
	/**
	 * 생성자
	 * <pre>
	 * 2007. 08. 09
	 * </pre>
	 */
	public FrameConfigReader() {
		super("FrameConfigReader");
	}
	
	/**
	 * 초기화
	 * <pre>
	 * 2007. 08. 09
	 * </pre>
	 * @throws FrameException 
	 */
	public void initialize(String fileName) throws FrameException {
		if (fileName == null) {
			throw new FrameException("FRAME 구성 파일("+fileName+")을 찾을 수 없습니다. 설정을 확인하십시요.");
		}
		
		fileName = fileName.replace('\\', '/');
		configFile = new File(fileName);
	}
	
	/**
	 * 파일 로드 및 XML 언마샬링
	 * <pre>
	 * 2007. 08. 10
	 * </pre>
	 * @throws FrameException 
	 */
	public void load() throws FrameException {
        try {
        	JAXBContext jc = JAXBContext.newInstance("com.cni.fw.ff.conf.frame.binder");
            Unmarshaller u = jc.createUnmarshaller();
            frameConfig = (FrameConfig) u.unmarshal(new FileInputStream(configFile));
        } catch(Exception e) {
        	throw new FrameException(e);
        }
	}
	
	/**
	 * 프레임리스트 확인.
	 * 
	 * <pre>
	 * 2007. 08. 10
	 * </pre>
	 */
	public void show() {

		FrameListType frameListType = frameConfig.getFrameList();
		FrameType frameType = null;
		List frameList = frameListType.getFrame();
		
		int cnt = 1;
		
		for (int i = 0; i < frameList.size(); i++) {
			frameType = (FrameType) frameList.get(i);
			if (frameType.isUsing()) {
				fatal("FMB #"+cnt+"-"+frameType.getName()+ " : "+frameType.getClassName() );
				cnt++;
			}
//			debug(frameType.getName());
//			debug(frameType.getClassName());
//			debug(frameType.getLoggerName());
			//debug(frameType.getParamList());
		}
		
	}

	/**
	 * 프레임리스트 getter
	 * <pre>
	 * 2007. 08. 10
	 * </pre>
	 * @return
	 */
	public FrameConfig getFrameConfig() {
		return frameConfig;
	}

}
